module banking.app 
{
    requires banking.core;
}