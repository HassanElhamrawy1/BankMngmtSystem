module banking.core {
    exports com.bank.model;
    exports com.bank.repository;
    exports com.bank.service;
    exports com.bank.util;
}