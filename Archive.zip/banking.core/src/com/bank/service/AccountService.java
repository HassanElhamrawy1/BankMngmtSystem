/* Contains operations on a single account (deposit, withdraw, applyInterest). */

package com.bank.service;

public class AccountService 
{

}
