package com.bank.repository;

import com.bank.model.Account;

public class InMemoryAccountRepository extends InMemoryRepository<Account> implements AccountRepository 
{
	
}