package com.bank.repository;

import com.bank.model.Account;

public interface AccountRepository extends Repository<Account> 
{
	 /* TO DO Account specific Logic*/
}