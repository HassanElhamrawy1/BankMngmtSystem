package com.bank.repository;

import com.bank.model.Customer;
import java.util.List;

import com.bank.model.Customer;

public interface CustomerRepository extends Repository<Customer> 
{
   /* TO DO Customer specific Logic*/
}
