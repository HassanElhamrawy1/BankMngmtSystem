package com.bank.model;


public interface Identifiable 
{
    String getId();
}
