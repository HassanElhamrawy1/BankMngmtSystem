/* Enum: DEPOSIT, WITHDRAW, TRANSFER. */

package com.bank.model;

public class TransactionType 
{

}
