/* Represents a bank transaction (Deposit/Withdraw/Transfer) with a timestamp. */

package com.bank.model;

public class Transaction 
{

}
