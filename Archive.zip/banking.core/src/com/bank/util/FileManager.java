/* Utility class for file reading/writing (can be used later). */

package com.bank.util;

public class FileManager 
{

}
